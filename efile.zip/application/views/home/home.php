<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <!-- <h4 class="page-title pull-left">Dashboard</h4> -->
                <ul class="breadcrumbs pull-left">
                    <!-- <li><a href="">Home</a></li> -->
                    <li>
                        <span>
                            <h4 class="page-title pull-left"><?= $title; ?></h4>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body text-center">
                    <!--<h4 class="header-title text-primary">Selamat Datang</h4>-->
                    <img src="<?= base_url('assets/images/bg/e-file.png'); ?>" width="250px">
                     <h5>BADAN PENGELOLAAN KEUANGAN DAERAH</h5> 
                </div>
            </div>
        </div>
        <!-- Dark table end -->
    </div>
</div>
<!-- main content area end -->